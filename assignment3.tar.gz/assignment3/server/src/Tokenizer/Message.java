package Tokenizer;

public interface Message<T> {

}
